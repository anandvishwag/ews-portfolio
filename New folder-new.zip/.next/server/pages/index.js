"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 2500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ Apis)
/* harmony export */ });
/* unused harmony export API_URL */
const API_URL = "http://adminportfolio.articloo.com";
const Apis = {
    GetCategoryWisePortfolio: `${API_URL}/api/categoryWisePortfolio`
};



/***/ }),

/***/ 1252:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./config/index.js
var config = __webpack_require__(2500);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: external "lightgallery/react"
const react_namespaceObject = require("lightgallery/react");
var react_default = /*#__PURE__*/__webpack_require__.n(react_namespaceObject);
;// CONCATENATED MODULE: external "react-icons/io5"
const io5_namespaceObject = require("react-icons/io5");
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/CategoryTab.js









const CategoryTab = ({ data  })=>{
    const { 0: selectedData , 1: setSelectedData  } = (0,external_react_.useState)(data.categories[0]);
    const { 0: portfolio , 1: setPortfolio  } = (0,external_react_.useState)(selectedData.children[0]);
    const handleChangeMainCategory = (mainCategoryId)=>{
        const category = data.categories.find((el)=>el.id === mainCategoryId);
        setSelectedData(category);
        setPortfolio(category.children[0]);
    };
    const handleChangeSubcategory = (subCategoryId)=>{
        setPortfolio(selectedData.children.find((el)=>el.id === subCategoryId));
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "citegorynav",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "cat-menu",
                    children: data.categories.map((item)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            onClick: ()=>handleChangeMainCategory(item.id),
                            className: selectedData.id === item.id ? "active" : "",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: item.icon
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: item.title
                                })
                            ]
                        }, item.id);
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "mainsection",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex aic filter",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    children: selectedData.title
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "filtenav",
                                    children: selectedData.children.map((item, index)=>{
                                        return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: portfolio.id === item.id ? "active" : "",
                                                onClick: ()=>handleChangeSubcategory(item.id),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    children: item.title
                                                })
                                            })
                                        }, index);
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "gallery",
                            children: portfolio && portfolio.portfolios.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx((react_default()), {
                                speed: 500,
                                children: portfolio.portfolios.map((item)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-3 col-sm-4 col-xs-6",
                                        "data-src": item.big_image,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: item.thumbnail,
                                            alt: item.title,
                                            width: 270,
                                            height: 232
                                        })
                                    }, item.id);
                                })
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "data-error",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(io5_namespaceObject.IoWarning, {}),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Data not found !"
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_CategoryTab = (CategoryTab);

;// CONCATENATED MODULE: ./pages/index.js





// Implement getServerSideProps to fetch data
async function getServerSideProps(context) {
    // Fetch data from an API or database
    const res = await fetch(`${config/* Apis.GetCategoryWisePortfolio */.y.GetCategoryWisePortfolio}`);
    const data = await res.json();
    // Pass fetched data to the page component props
    return {
        props: {
            data
        }
    };
}
const Home = ({ data  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Explosionweb Solutions"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Explosionweb Solutions is a multifaceted young organization. We specialize in creating top-notch web solutions for your business. We are a team of dedicated and creative professionals continuously working towards making your business realize its true online potential. We have a bold and promising approach to digital marketing, branding, App development and many more online service"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_CategoryTab, {
                    data: data
                })
            })
        ]
    });
};
Home.layout = "Main";
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,675], () => (__webpack_exec__(1252)));
module.exports = __webpack_exports__;

})();