

const API_URL = "http://adminportfolio.articloo.com";

const Apis = {
    GetCategoryWisePortfolio:`${API_URL}/api/categoryWisePortfolio`,

};
export { API_URL, Apis };
